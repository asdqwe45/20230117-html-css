<template>
  <div>
    주문 등록
  </div>
</template>

<script>


export default {
  data(){
    return {

    }
  }
};
</script>

<style scoped>

</style>