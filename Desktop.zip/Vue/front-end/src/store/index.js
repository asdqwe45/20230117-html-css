import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    menus:[],
  },
  getters: {
  },
  mutations: {
    SET_MY_DATA(state,data){
      state.menus=data;
    }
  },
  actions: {
  },
  modules: {
  }
})
