<template>
  <div>
    <h1>Detail</h1>
    <div>{{ menuId }}번 메뉴 디테일페이지입니다.</div>
    <div>{{ $store.state.menus[menuId] }}</div>
  </div>
</template>

<script>
  export default{
    data(){
      return{
        menuId:-1,
      }
    },
    created(){
      console.log(this.$route.params.id);
      this.menuId=this.$route.params.id;
    }
  }
</script>