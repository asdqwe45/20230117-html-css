<template>
  <div>
    <h1>Detail</h1>
    <div>여기는 {{id}}의 디테일 페이지입니다.</div>
  </div>
</template>
<script>
export default {
  data(){
    return{
    id:null,
    }
  },
  created(){
   // console.log(this.$router);  다른 페이지도 가져올 수 있음
   // console.log(this.$route);  현재 페이지에 있는 것ㅁ나 가져옴
    this.id=this.$route.params.id;   // 각 각의 경로
  }
}
</script>

