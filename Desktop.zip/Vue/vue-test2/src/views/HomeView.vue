<template>
  <div>
    <h1>할배</h1>
    <div>{{ halbaeData }}</div>
    <HomeParent
      :halbaeData="halbaeData"
      :halbaeData2="halbaeData2"
      @changeHalbaeData="changeHalbaeData" 
      @changeHalbaeDataFromChild="changeHalbaeData"
    ></HomeParent>
  </div>
</template>

<script>
import HomeParent from "@/components/HomeParent.vue";

export default {
  components: {
    HomeParent,
  },
  data() {
    return {
      halbaeData: "나는 할배데이터!",
      halbaeData2: "나는 두전째할배",
    };
  },
  methods: {
    changeHalbaeData(text) {
      this.halbaeData=text;
    },
  },
};
</script>
