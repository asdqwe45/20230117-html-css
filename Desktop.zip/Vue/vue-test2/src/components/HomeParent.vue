<template>
  <div>
    <h1>아빠</h1>
    <div>{{ halbaeData }}</div>
    <div>{{ halbaeData2 }}</div>
    <button @click="changeHalbaeData">아빠가 바꾼다.</button>
    <ParentChild :halbaeData="halbaeData" 
    @changeHalbaeDataFromChild="changeHalbaeDataFromChild"
    
    />
  </div>
</template>

<script>
import ParentChild from "./ParentChild.vue";

export default {
  components: { ParentChild },
  props: ["halbaeData", "halbaeData2"],
  methods:{
    changeHalbaeData(){
      this.$emit("changeHalbaeData","아빠가 바꿨다");
    },
    changeHalbaeDataFromChild(text){
      this.$emit("changeHalbaeData",text);
    }
  }
};
</script>
