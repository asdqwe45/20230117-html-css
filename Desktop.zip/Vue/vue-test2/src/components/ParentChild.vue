<template>
  <div>
    <h1>나</h1>
    <div>{{ halbaeData }}</div>
    <button @click="changeHalbaeDataFromChild">내가 바꾼다.</button>
  </div>
</template>

<script>
export default {
  props: ["halbaeData"],
  methods:{
    changeHalbaeDataFromChild(){
      this.$emit("changeHalbaeDataFromChild","내가 바꿨다.");
    }
  }
};
</script>