<template>
  <div><h1>소개 페이지입니다.</h1></div>
</template>

<script>
export default {

}
</script>

<style>

</style>