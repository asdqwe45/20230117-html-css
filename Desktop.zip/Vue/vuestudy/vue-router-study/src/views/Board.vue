<template>
  <div><h1>게시판 입니다.</h1></div>
</template>

<script>
export default {

}
</script>

<style>

</style>