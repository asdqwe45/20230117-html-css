<template>
  <div>
    <input type="password" name="" id="">
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>