<template>
  <div>
    <h1>HEADER</h1>
    <Search></Search>
  </div>
</template>

<script>
import Search from "./Search.vue"

export default{
components:{
  Search
}
}
</script>

<style>

</style>