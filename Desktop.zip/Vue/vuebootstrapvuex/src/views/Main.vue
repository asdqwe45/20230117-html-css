<template>
  <div>
    메인
    <router-link to="/todos">
      리스트 목록으로 이동
    </router-link>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>